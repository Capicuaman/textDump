---
layout:     post
title:      Welcome to Carte Noire
date:       2015-03-23 15:31:19
author:     Jacob Tomlinson
summary:    Carte Noire is a dark blog theme for Jekyll focusing on a clear reading experience.
categories: jekyll
thumbnail:  heart
tags:
 - welcome
 - to
 - carte
 - noire
---

Welcome to Carte Noire.

Carte Noire began as a new theme for [my personal blog][1], but has now taken
on a life of its own as a free theme for Jekyll.

The theme has been designed with simplicity and readability in mind. It makes
use of third party services such as Disqus ad AddThis to ensure the blog has
all the features you would expect from a dynamic application such as Wordpress
but with the hosting and maintenance simplicity of Jekyll.

Please use/copy/share Carte Noire!

[1]: http://www.jacobtomlinson.co.uk/
